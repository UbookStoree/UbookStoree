<?php

namespace EventsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EventsBundle extends Bundle
{
}
