<?php

namespace AchatBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AchatBundle extends Bundle
{
}
